# coding=utf-8
import time

# Keys
KEY_1 = 49
KEY_2 = 50
KEY_3 = 51
KEY_4 = 52
KEY_5 = 53
KEY_6 = 54
KEY_7 = 55
KEY_8 = 56
KEY_9 = 57
KEY_0 = 48
KEY_MINUS = 189  # -
KEY_EQUAL = 187  # =
KEY_BACK = 8
KEY_A = 65
KEY_B = 66
KEY_C = 67
KEY_D = 68
KEY_E = 69
KEY_F = 70
KEY_G = 71
KEY_H = 72
KEY_I = 73
KEY_J = 74
KEY_K = 75
KEY_L = 76
KEY_M = 77
KEY_N = 78
KEY_O = 79
KEY_P = 80
KEY_Q = 81
KEY_R = 82
KEY_S = 83
KEY_T = 84
KEY_U = 85
KEY_V = 86
KEY_W = 87
KEY_X = 88
KEY_Y = 89
KEY_Z = 90
KEY_CTRL = 17
KEY_ALT = 18
KEY_SHIFT = 16
KEY_WIN = 91
KEY_SPACE = 32
KEY_CAP = 20
KEY_TAB = 9
KEY_TILDE = 192
KEY_ESC = 27
KEY_ENTER = 13
KEY_UP = 38
KEY_DOWN = 40
KEY_LEFT = 37
KEY_RIGHT = 39
KEY_OPTION = 93
KEY_PRINT = 44
KEY_DELETE = 46
KEY_HOME = 36
KEY_END = 35
KEY_PGUP = 33
KEY_PGDN = 34
KEY_F1 = 112
KEY_F2 = 113
KEY_F3 = 114
KEY_F4 = 115
KEY_F5 = 116
KEY_F6 = 117
KEY_F7 = 118
KEY_F8 = 119
KEY_F9 = 120
KEY_F10 = 121
KEY_F11 = 122
KEY_F12 = 123
KEY_L_BRACKET = 219  # [
KEY_R_BRACKET = 221  # ]
KEY_BACKSLASH = 220  # \
KEY_SEMICOLON = 186  # ;
KEY_QUOTE = 222  # '
KEY_COMMA = 188  # ,
KEY_POINT = 190  # .
KEY_FORWARD_SLASH = 191  # /


def log(msg):
    print(msg)


class DM:
    def __init__(self, window_class, window_title):
        self.window_class = window_class
        self.window_title = window_title
        self.hwnd = None
        self.offset_x = 0
        self.offset_y = 0
        self.window_w = None
        self.window_h = None
        import win32com.client
        self.dll = win32com.client.Dispatch("dm.dmsoft")
        log("dm dll Loading succeeded")

    def update_rect(self):
        """更新窗口位置, 返回更新后位置"""
        if not (self.window_class or self.window_title):
            if not self.window_class:
                log("class is empty")
            if not self.window_title:
                log("title is empty")
            raise RuntimeError("Class or title is empty")
        self.hwnd = self.dll.FindWindow(self.window_class, self.window_title)
        _, self.offset_x, self.offset_y, x, y = self.dll.GetWindowRect(self.hwnd)
        self.window_w = x - self.offset_x
        self.window_h = y - self.offset_y
        print(self.offset_x, self.offset_y)
        log("class: {}, title: {}, handle: {}\noffset(x: {}, y: {}), window(width: {}, height: {})"
            .format(self.window_class, self.window_title, self.hwnd,
                    self.offset_x, self.offset_y, self.window_w, self.window_h))
        return self.offset_x, self.offset_y, self.window_w, self.window_h


class Config:
    def __init__(self):
        self.mini_map = None
        self.id = "1"
        self.api_server = "127.0.0.0"
        self.port = "8080"
        self.resource_path = r".\resource"
        self.config_file = "config"
        self.player = "player.bmp"
        self.wheel = "wheel.bmp"
        self.temp = "temp.jpg"

    def set_resource(self, config):
        import os
        # config
        self.config_file = os.path.join(self.resource_path, config)
        if not os.path.exists(self.config_file):
            msg = "Unable to find configuration file: {}".format(self.config_file)
            log(msg)
            raise RuntimeError(msg)
        log("config: {}".format(self.config_file))
        # player
        self.player = os.path.join(self.resource_path, self.player)
        if not os.path.exists(self.config_file):
            msg = "Unable to find img player: {}".format(self.player)
            log(msg)
            raise RuntimeError(msg)
        # wheel
        self.wheel = os.path.join(self.resource_path, self.wheel)
        if not os.path.exists(self.wheel):
            msg = "Unable to find img wheel: {}".format(self.wheel)
            log(msg)
            raise RuntimeError(msg)

    def init(self, config=None):
        if config is None:
            config = self.config_file
        self.set_resource(config)
        with open(self.config_file, "r") as cfg:
            for line in cfg.readlines():
                line = line.split("#")[0].strip()
                if len(line) == 0:
                    continue
                line = line.lower().split("=")
                if line[0] == "server":
                    self.api_server = line[1]
                elif line[0] == "id":
                    self.id = line[1]
                elif line[0] == "port":
                    self.port = line[1]
        log("api server: {}:{}, Local Id: {}".format(self.api_server, self.port, self.id))
        return self

    def send_pic(self):
        pass

    def send_alarm(self):
        pass


class Action:
    def __init__(self, config, dm, attack=None, jump=None, blink=None):
        self.btn_attack = attack
        self.btn_jump = jump
        self.btn_blink = blink
        self.dll = dm.dll
        self.dm = dm
        self.config = config
        self.mini_map_x = None
        self.mini_map_y = None
        self.mini_map_w = None
        self.mini_map_h = None

    def init(self, map_size):
        x, y, w, h = self.dm.update_rect()
        self.mini_map_x, self.mini_map_y, self.mini_map_w, self.mini_map_h = map_size
        self.mini_map_x = self.mini_map_x + x
        self.mini_map_y = self.mini_map_y + y + 20
        return self

    def find_mini_map(self, target, offset='101010', sim=.8, dire=0):
        w = self.mini_map_w + self.dm.offset_x
        h = self.mini_map_h + self.dm.offset_y
        _, x, y = self.dll.FindPic(self.mini_map_x, self.mini_map_y, w, h, target, offset, sim, dire)
        print("mini_map_x", self.mini_map_x, self.mini_map_y, self.dm.offset_x, self.dm.offset_y, self.mini_map_w,
              self.mini_map_h)
        print("x", x, y, w, h)
        return x, y

    def close_to_target(self, x, y, gap_x=1, gap_y=1, far_away=30):
        [self.dll.KeyUp(k) for k in [KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT]]
        log("Getting close to the target")
        while True:
            xp, yp = self.find_mini_map(self.config.player)
            # It's far away
            if xp - x > far_away:
                self.dll.KeyDown(KEY_LEFT)
                self.blink()
                self.dll.KeyUp(KEY_LEFT)
            elif xp - x < -far_away:
                self.dll.KeyDown(KEY_RIGHT)
                self.blink()
                self.dll.KeyUp(KEY_RIGHT)
            # It's very close
            if xp - x > gap_x:
                self.dll.KeyDown(KEY_LEFT)
                time.sleep(0.1)
                self.dll.KeyUp(KEY_LEFT)
            elif xp - x < -gap_x:
                self.dll.KeyDown(KEY_RIGHT)
                time.sleep(0.1)
                self.dll.KeyUp(KEY_RIGHT)
            else:
                if yp - y > gap_y:
                    self.go_up()
                    time.sleep(1)
                elif yp - y < -gap_y:
                    self.go_down()
                    time.sleep(1)
                else:
                    log("Approaching the target")
                    break

    def key_down(self, key):
        self.dll.KeyDown(key)
        return self

    def key_up(self, key):
        self.dll.KeyUp(key)
        return self

    def key_hold(self, key, *args):
        self.dll.KeyDown(key)
        for p in args:
            p()
        self.dll.KeyUp(key)

    def key_press(self, key, duration=0):
        if duration:
            self.dll.key_press(key)
        else:
            self.dll.KeyDown(key)
            time.sleep(duration)
            self.dll.KeyUp(key)

    def move_left(self, duration=0):
        self.key_press(KEY_LEFT, duration)
        return self

    def move_right(self, duration=0):
        self.key_press(KEY_RIGHT, duration)
        return self

    def move_up(self, duration=0):
        self.key_press(KEY_UP, duration)
        return self

    def move_down(self, duration=0):
        self.key_press(KEY_DOWN, duration)
        return self

    def attack(self):
        self.key_press(self.btn_attack)
        return self

    def jump(self):
        self.key_press(self.btn_jump)
        return self

    def blink(self):
        self.key_press(self.btn_blink)
        return self

    def sleep(self, duration):
        time.sleep(duration)
        return self

    def policy(self):
        pass

    def hit_and_run(self, dire):
        pass

    def go_down(self):
        pass

    def go_up(self):
        pass
