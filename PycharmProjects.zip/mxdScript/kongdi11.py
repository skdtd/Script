# coding=utf-8
import keyboard

from ScriptConfig import *


class KongDi(Action):
    def __init__(self, config, dm_dll, attack, jump, blink):
        Action.__init__(self, config, dm_dll, attack, jump, blink)

    def policy(self):
        current_direction = KEY_RIGHT
        print("loop start")
        while True:
            x, y = self.find_mini_map(self.config.player)
            wheel_x, wheel_y = self.find_mini_map(self.config.wheel)
            print(x, y)
            print(wheel_x, wheel_y)
            if wheel_x != -1:
                pass
            if x == -1 and current_direction == KEY_RIGHT:  # 在最右侧迷失时调头
                print("miss target move to left")
                current_direction = KEY_LEFT
            elif x == -1 and current_direction == KEY_LEFT:  # 在最左侧迷失时调头
                print("miss target move to right")
                current_direction = KEY_RIGHT
            if current_direction == KEY_LEFT and 0 < x < 45 + self.mini_map_x:
                current_direction = KEY_RIGHT
            elif current_direction == KEY_RIGHT and x > 145 + self.mini_map_x:
                current_direction = KEY_LEFT
            self.hit_and_run(current_direction)

    def hit_and_run(self, dire):
        self.key_down(dire).jump().sleep(0.2).jump().attack().key_up(dire)

    def go_down(self):
        self.key_down(KEY_DOWN).sleep(0.1).jump().sleep(0.1).key_up(KEY_DOWN)

    def go_up(self):
        self.jump().move_up(0).sleep(0.1).move_up(0).jump()


if __name__ == "__main__":
    mini_map = (5, 60, 185, 90)  # 机械坟场空地
    dm = DM("MapleStory", "")
    dm.update_rect()
    cfg = Config().init()
    act = KongDi(cfg, dm, attack=KEY_Z, jump=KEY_C, blink=KEY_E).init(mini_map)
    keyboard.wait("F6")
    act.policy()
    keyboard.wait()
