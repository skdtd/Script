# coding=utf-8
import psutil
import win32com.client
import win32process

DM = win32com.client.Dispatch("dm.dmsoft")
print("dm version: " + DM.ver())
hwnd = DM.FindWindow("MapleStory", "")
_, PID = win32process.GetWindowThreadProcessId(hwnd)  # 通过句柄ID查询进程PID（第0个元素不管，第1个元素是PID）
p = psutil.Process(PID)  # 实例化PID
p.terminate()


