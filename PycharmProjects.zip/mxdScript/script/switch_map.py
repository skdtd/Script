# coding=utf-8
MAPS = {
    "机械坟场": {}
}


def switch_map(target):
    pass
